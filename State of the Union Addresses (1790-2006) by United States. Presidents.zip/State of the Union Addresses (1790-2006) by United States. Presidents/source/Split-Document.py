# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

import re

f=open('pg5050.txt','r')
content=f.read()
f.close()

for address in content.split('***'):
    try:
        title = re.sub('[\W_]+', '_', address.splitlines()[4][-4:])+'_'+re.sub('[\W_]+', '_', address.splitlines()[4][:-4])+re.sub('[\W_]+', '_', address.splitlines()[3])
        print(title)
        fout = open(title+'.txt', 'w')
        for line in range(5,len(address.splitlines())+1):
            fout.write(address.splitlines()[line]+'\n')
        fout.close()
    except:
        pass

